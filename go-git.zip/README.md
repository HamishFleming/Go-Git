# git-id

Small Go CLI for managing multiple Git identities and SSH keys on a repo/path basis.

It stores rules in `~/.config/git-id/config.json` and can generate Git `includeIf` config snippets so Git automatically uses the correct `user.name`, `user.email`, and `core.sshCommand` based on the repository path.

## Build

```bash
go build -o git-id ./cmd/git-id
```

## Example

```bash
# Add identities
git-id user add personal \
  --git-name "Hamish Fleming" \
  --git-email "hamish@example.com" \
  --ssh-key ~/.ssh/id_ed25519_personal

git-id user add work \
  --git-name "Hamish Fleming" \
  --git-email "hamish@company.com" \
  --ssh-key ~/.ssh/id_ed25519_work

# Match repo roots or directory trees to identities
git-id path add ~/code/personal personal
git-id path add ~/work work

# Generate ~/.config/git-id/includes/*.gitconfig and print the ~/.gitconfig block
git-id apply
```

Add the printed block to `~/.gitconfig`:

```gitconfig
[includeIf "gitdir:~/code/personal/**"]
    path = ~/.config/git-id/includes/personal.gitconfig
```

Then any repository under that path gets the configured identity and SSH key.

## Directly apply to the current repo

```bash
git-id use work
```

This writes to `.git/config` for the current repository:

```gitconfig
[user]
    name = Hamish Fleming
    email = hamish@company.com
[core]
    sshCommand = ssh -i ~/.ssh/id_ed25519_work -o IdentitiesOnly=yes
```

## Commands

```text
git-id init
git-id user add <alias> --git-name <name> --git-email <email> --ssh-key <path>
git-id user rm <alias>
git-id path add <path> <user-alias>
git-id path rm <path>
git-id list
git-id resolve [path]
git-id apply
git-id use <user-alias> [repo-path]
```
